<?php	
	$this->load->view("stationary/layout/stationary_header");
 	$this->load->view("stationary/layout/stationary_sidebar");
 	$this->load->view("stationary/".$middle_content);
	 $this->load->view("stationary/layout/stationary_footer");
?>