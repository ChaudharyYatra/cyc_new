



</div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
 

    <div class="float-right d-none d-sm-block">
      <!--<b>Version</b> 3.2.0-->
    </div>
    <center><strong>Copyright &copy; <?php echo date("Y"); ?>.</strong> All rights reserved.</center>
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->


<!-- jQuery -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/jquery-validation/jquery.validate.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/jquery-validation/additional-methods.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/summernote/summernote-bs4.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/codemirror/codemirror.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/codemirror/mode/css/css.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/codemirror/mode/xml/xml.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/codemirror/mode/htmlmixed/htmlmixed.js"></script>

<script src="<?php echo base_url(); ?>assets/admin/plugins/select2/js/select2.full.min.js"></script>
<!-- Bootstrap4 Duallistbox -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/bootstrap4-duallistbox/jquery.bootstrap-duallistbox.min.js"></script>
<!-- InputMask -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/moment/moment.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/inputmask/jquery.inputmask.min.js"></script>
<!-- date-range-picker -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/daterangepicker/daterangepicker.js"></script>
<!-- bootstrap color picker -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js"></script>
<!-- Tempusdominus Bootstrap 4 -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
<!-- Bootstrap Switch -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/bootstrap-switch/js/bootstrap-switch.min.js"></script>
<!-- BS-Stepper -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/bs-stepper/js/bs-stepper.min.js"></script>
<!-- dropzonejs -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/dropzone/min/dropzone.min.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url(); ?>assets/admin/dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url(); ?>assets/admin/dist/js/demo.js"></script>

<!-- Page specific script -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/select2/js/select2.full.min.js"></script>

<!-- Summernote -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/summernote/summernote-bs4.min.js"></script>
<!-- CodeMirror -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/codemirror/codemirror.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/codemirror/mode/css/css.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/codemirror/mode/xml/xml.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/codemirror/mode/htmlmixed/htmlmixed.js"></script>


<!-- date-range-picker -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/daterangepicker/daterangepicker.js"></script>
<!-- bootstrap color picker -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js"></script>
<!-- Tempusdominus Bootstrap 4 -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
<!-- Bootstrap Switch -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/bootstrap-switch/js/bootstrap-switch.min.js"></script>
<!-- BS-Stepper -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/bs-stepper/js/bs-stepper.min.js"></script>
<!-- dropzonejs -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/dropzone/min/dropzone.min.js"></script>



<script src="<?php echo base_url(); ?>assets/admin/plugins/bootstrap4-duallistbox/jquery.bootstrap-duallistbox.min.js"></script>
<!-- InputMask -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/moment/moment.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/inputmask/jquery.inputmask.min.js"></script>

<!-- DataTables  & Plugins -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/jszip/jszip.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/pdfmake/pdfmake.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/pdfmake/vfs_fonts.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/datatables-buttons/js/buttons.html5.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/datatables-buttons/js/buttons.print.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/datatables-buttons/js/buttons.colVis.min.js"></script>

<script>
  $(function () {
    $("#example1").DataTable({
      "responsive": true, "lengthChange": false, "autoWidth": false,
      "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });
  });
</script>



<script>  
 $(document).ready(function(){  
 // var email = $('#agent_sess_id').val();  
           var agent_id = '1'; 
           if(agent_id != '')  
           {  
                $.ajax({  
                     url:"<?php echo base_url(); ?>agent/dashboard/check_notification_count",  
                     method:"POST",  
                     data:{agent_id:agent_id},  
                     success:function(responce){ 
                        //  console.log(responce);
                        //  console.log('jjjjjjjjjjjjjjjjjjjj');
                         if(responce > 0)
                         {
                            $('#notification_count').append('<i class="fas fa-envelope mr-2"></i> '+responce+' Domestic Packages');
                            // $('#btn_agent').prop('disabled', true)
                             
                         }else
                         {
                             $('#notification_count').html('');
                            //  $('#btn_agent').prop('disabled', false)
                         } 
                     }  
                });  
           }  
      });  
 </script>

<script>  
 $(document).ready(function(){
  $("#notification_count").click(function() {  
 // var email = $('#agent_sess_id').val();  
           var agent_id = '0'; 
           if(agent_id != '')  
           {  
                $.ajax({  
                     url:"<?php echo base_url(); ?>agent/dashboard/enquiry_view",  
                     method:"POST",  
                     data:{agent_id:agent_id},  
                     success:function(responce){ 
                         if(responce = true)
                         {
                              // (responce);
                          // redirect($this->module_url_path.'agent/booking_enquiry/index');
                         }
                     }  
                });  
           } 
          }); 
      });  
 </script>


<script>  
 $(document).ready(function(){  
 // var email = $('#agent_sess_id').val();  
           var agent_id = '1'; 
           //(email);
           if(agent_id != '')  
           {  
                $.ajax({  
                     url:"<?php echo base_url(); ?>agent/dashboard/check_international_count",  
                     method:"POST",  
                     data:{agent_id:agent_id},  
                     success:function(responce){ 
                         if(responce > 0)
                         { 
                            $('#international_count').append('<i class="fas fa-users mr-2"></i> '+responce+' International Packages');
                            // $('#btn_agent').prop('disabled', true)
                             
                         }else
                         {
                             $('#international_count').html('');
                            //  $('#btn_agent').prop('disabled', false)
                         } 
                     }  
                });  
           }  
      });  
 </script>

<script>  
 $(document).ready(function(){
  $("#international_count").click(function() {  
 // var email = $('#agent_sess_id').val();  
           var agent_id = '1'; 
           //(email);
           if(agent_id != '')  
           {  
                $.ajax({  
                     url:"<?php echo base_url(); ?>agent/dashboard/international_view",  
                     method:"POST",  
                     data:{agent_id:agent_id},  
                     success:function(responce){ 
                         if(responce = true)
                         {
                          // redirect($this->module_url_path.'agent/booking_enquiry/index');
                          window.location.href = "<?=base_url()?>agent/international_booking_enquiry/index";
                         }
                     }  
                });  
           } 
          }); 
      });  
 </script>

<!-- <script>
 $('.send_qty').keyup(function(){ 
     var p=$('.send_qty').val(); 
     (p.length); 
     var currentRow=$(this).closest("tr"); 
     var col3=currentRow.find("td:eq(2)").text(); 
     ////(col3);
     
$(".send_qty").each(function () {                
    var send_qty = $(this).val(); 
     
     if(send_qty!='')
     {
          $('.cancel_status').hide();
          $('#submit').attr("disabled", true);
     }
     else{
          $('.cancel_status').show();
          $('#submit').attr("disabled", false);
     }

 });
 });
</script> -->


<script>
  $(document).ready(function(){ 
  $('#not_in_stock').click(function(){ 
  $('input[name="send_qty[]"]').val('Not in stock');
   });
});
</script>

<!-- without enter sending qu -->
<script>
$('.sendButton').attr("disabled", true);

$('.send_qty').on('keyup', function() {

     var p=$(this).val(); 
     console.log(p); 
     var currentRow=$(this).closest("tr"); 
     var col3=currentRow.find("td:eq(2)").text(); 
     console.log(parseInt(col3));
     if(parseInt(p) <= parseInt(col3) && p >0)
     {
$(".send_qty").each(function () {                
    var s_send = $(this).val(); 
     if(s_send!='')
     {
          $('.sendButton').attr("disabled", false);
     }
     else{
          $('.sendButton').attr("disabled", true);
     }
     });
}else{
     $('.sendButton').attr("disabled", true);
     alert('Please insert less quantity or equal quantity');
}
});
</script>

<!-- using ajax submit send qty then open modal -->
<script>


  $("#submit").click(function() { 
     var new_array_qty = [];
     var new_array_sod = [];
     var o_id =  $(".order_id").val();

     $(".send_qty").each(function () 
     {                
          var s_send = $(this).val();
          new_array_qty.push($(this).val()) 
     });

     $(".stationary_order_id").each(function () 
     {  
          var so_id =  $(this).val();
          new_array_sod.push($(this).val())
               
     });

     $("#od_id").val(new_array_sod);
     if(new_array_qty!='')
     {
          $.ajax({
                          type: "POST",
                          url:'<?=base_url()?>stationary/stationary_request/send',
                          data: {s_send: new_array_qty,
                              so_id: new_array_sod,
                              o_id: o_id
                           },
                         //  dataType: 'json',
                         //  cache: false,
                          success: function(response) {
                              console.log(response);
                               if (response= true) {
                                  $('#exampleModal_send').modal('show'); 
                              } else {
                                  alert('error');

                              }
                          },
                          
                      });
     }
     // else{
     //      $('.sendButton').attr("disabled", true);
     // }
}); 

</script>

<!-- new code stationary as per client changes -->

<script>

    $('.send_qty').keyup(function(){
        var count = $(this).val();
        var attrval =$(this).attr('attr-series_yes_no');
        var attrval_stid =$(this).attr('attr_stid');

        

      if(attrval =="Yes"){ 

        $.ajax({
        url:'<?=base_url()?>stationary/stationary_request/get_series', 
        method: 'post',
        data: {stationary_id: attrval_stid},
        dataType: 'json',
        success: function(response){
        console.log(response);
        
          // $('#agent_center').find('option').not(':first').remove();
       
          // $.each(response,function(index,data){             
          //    $('#agent_center').append('<option value="'+data['id']+'">'+data['booking_center']+'</option>');
          // });
        
          $('.detail_tr').remove(); 

            for(var i=0; i<count; i++){
            
        var structure = $(` 

               <tr class="detail_tr">
                  <td>
                    <select class="form-control" style="width: 100%;" name="academic_year[]" id="academic_year" required="required">
                      <option value="">Select year</option>
                      <?php
                          foreach($academic_years_data as $academic_years_info) 
                          { 
                      ?>
                          <option value="<?php echo $academic_years_info['id']; ?>"><?php echo $academic_years_info['year']; ?></option>
                      <?php } ?>
                    </select>
                  </td>
                  <td>
                    <select class="form-control" style="width: 100%;" name="from_series[]" id="series_data`+i+`" required="required"
                    attr_row_count="`+count+`">
                        <option value="">Select series</option>
                       
                    </select>
                  </td>
                  <td>
            <input type="text" class="form-control remark" name="remark[]" value="" id="remark" placeholder="Remark"/>

                  </td>
               </tr>
                                   

               `);
        
         
            $('#series_yes').append(structure); 

            var sid='series_data'+i;                
            $('#'+sid).find('option').not(':first').remove();
       
          $.each(response,function(index,data){             
             $('#'+sid).append('<option value="'+data['id']+'">'+data['from_series']+'-'+data['to_series']+'</option>');
          });
          
        }

      }
     }); 
     }
     else{
      $('.detail_tr').remove(); 
          for(var i=0; i<count; i++){

        var structure = $(` 

               <tr class="detail_tr">
                  <td>
                    <select class="form-control" style="width: 100%;" name="academic_year" id="academic_year" required="required">
                      <option value="">Select Year</option>
                      <?php
                          foreach($academic_years_data as $academic_years_info) 
                          { 
                      ?>
                          <option value="<?php echo $academic_years_info['id']; ?>"><?php echo $academic_years_info['year']; ?></option>
                      <?php } ?>
                    </select>
                  </td>
                  
                  
                  <td>
                  <input type="text" class="form-control" name="remark" id="remark" placeholder="Remark"/>

                  </td>
               </tr>
                                   

                    `);
        
         
            // $('#series_no').append(structure); 
        }
          
     }
       
    });

</script>

<script>

//   $(document).ready(function(){
//     var col3=0;
//     $('.send').on('click', function() {
//       // var currentRow=$(this).closest("tr"); 
//       var currentRow=$(this).closest("tr"); 
//       var col3=currentRow.find('input[name="send_qty[]"]').val();
//     });
//  for(var i=1; i<=col3;i++)
//  {
//   console.log(i);
//   var abc='series_data'+i;
//   $('#'+abc).on('change', function () {
//     var did = $(this).val();
//   });
// }
// });
 </script>  


<script>
      $(document).ready(function(){
    $('#save_series').on('click', function () {
        
      // var remark=new Array();
        var order_id = $('#order_id').val();
        var order_d_id = $('#order_d_id').val();
        var form_type = $('#form_type').val();
        var save_series='save_series';

        var from_series = $('select[name="from_series[]"]').map(function () {
            return this.value; // $(this).val()
        }).get();

        var academic_year = $('select[name="academic_year[]"]').map(function () {
            return this.value; // $(this).val()
        }).get();

        var remark = $('input[name="remark[]"]').map(function () {
            return this.value; // $(this).val()
        }).get();

        $.ajax({
                          method: 'post',
                          url:'<?=base_url()?>stationary/stationary_request/save_details',
                          data: {order_id: order_id,
                            order_d_id: order_d_id,
                            form_type: form_type,
                            academic_year: academic_year,
                            remark: remark,
                            save_series:save_series,
                            from_series:from_series
                        },
                          dataType: 'json',
                          cache: false,
                          success: function(response) {
                              if (response=true) {
                                   alert('success');
                                // window.location.href = "<?=base_url()?>admin/day_wise_tour_itinerary/add";
                              } else {
                                  alert('error');

                              }
                          },
                          
                      });

    }); 
    
    

    $('#save_no_series').on('click', function () {
        
        // var remark=new Array();
          var order_id = $('#order_id_no_series').val();
          var order_d_id = $('#order_d_id_no_series').val();
          var no_series='no_series';
          var academic_year = $('#a_year_no_series').val();
          var remark = $('#remark_no_series').val();

          $.ajax({
                            method: 'post',
                            url:'<?=base_url()?>stationary/stationary_request/save_details',
                            data: {order_id: order_id,
                              order_d_id: order_d_id,
                              academic_year: academic_year,
                              remark: remark,
                              no_series:no_series
                          },
                            dataType: 'json',
                            cache: false,
                            success: function(response) {
                                if (response=true) {
                                     alert('success');
                                  // window.location.href = "<?=base_url()?>admin/day_wise_tour_itinerary/add";
                                } else {
                                    alert('error');
  
                                }
                            },
                            
                        });
  
      });

});


 </script>


