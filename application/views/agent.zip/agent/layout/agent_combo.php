<?php	
	$this->load->view("agent/layout/agent_header");
 	$this->load->view("agent/layout/agent_sidebar");
 	$this->load->view("agent/".$middle_content);
	 $this->load->view("agent/layout/agent_footer");
?>