</div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <div class="float-right d-none d-sm-block">
      <!--<b>Version</b> 3.2.0-->
    </div>
    <center><strong>Copyright &copy; <?php echo date("Y"); ?>.</strong> All rights reserved.</center>
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->


<!-- jQuery -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/jquery-validation/jquery.validate.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/jquery-validation/additional-methods.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/summernote/summernote-bs4.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/codemirror/codemirror.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/codemirror/mode/css/css.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/codemirror/mode/xml/xml.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/codemirror/mode/htmlmixed/htmlmixed.js"></script>

<script src="<?php echo base_url(); ?>assets/admin/plugins/select2/js/select2.full.min.js"></script>
<!-- Bootstrap4 Duallistbox -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/bootstrap4-duallistbox/jquery.bootstrap-duallistbox.min.js"></script>
<!-- InputMask -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/moment/moment.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/inputmask/jquery.inputmask.min.js"></script>
<!-- date-range-picker -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/daterangepicker/daterangepicker.js"></script>
<!-- bootstrap color picker -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js"></script>
<!-- Tempusdominus Bootstrap 4 -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
<!-- Bootstrap Switch -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/bootstrap-switch/js/bootstrap-switch.min.js"></script>
<!-- BS-Stepper -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/bs-stepper/js/bs-stepper.min.js"></script>
<!-- dropzonejs -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/dropzone/min/dropzone.min.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url(); ?>assets/admin/dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url(); ?>assets/admin/dist/js/demo.js"></script>

<!-- Page specific script -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/select2/js/select2.full.min.js"></script>

<!-- Summernote -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/summernote/summernote-bs4.min.js"></script>
<!-- CodeMirror -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/codemirror/codemirror.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/codemirror/mode/css/css.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/codemirror/mode/xml/xml.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/codemirror/mode/htmlmixed/htmlmixed.js"></script>


<!-- date-range-picker -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/daterangepicker/daterangepicker.js"></script>
<!-- bootstrap color picker -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js"></script>
<!-- Tempusdominus Bootstrap 4 -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
<!-- Bootstrap Switch -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/bootstrap-switch/js/bootstrap-switch.min.js"></script>
<!-- BS-Stepper -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/bs-stepper/js/bs-stepper.min.js"></script>
<!-- dropzonejs -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/dropzone/min/dropzone.min.js"></script>



<script src="<?php echo base_url(); ?>assets/admin/plugins/bootstrap4-duallistbox/jquery.bootstrap-duallistbox.min.js"></script>
<!-- InputMask -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/moment/moment.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/inputmask/jquery.inputmask.min.js"></script>

<!-- DataTables  & Plugins -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/jszip/jszip.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/pdfmake/pdfmake.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/pdfmake/vfs_fonts.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/datatables-buttons/js/buttons.html5.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/datatables-buttons/js/buttons.print.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/datatables-buttons/js/buttons.colVis.min.js"></script>

<script>
  $(function () {
    $("#example1").DataTable({
      "responsive": true, "lengthChange": false, "autoWidth": false,
      "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });
  });
</script>



<script>  
 $(document).ready(function(){  
 // var email = $('#agent_sess_id').val();  
           var agent_id = '1'; 
           //alert(email);
           if(agent_id != '')  
           {  
                $.ajax({  
                     url:"<?php echo base_url(); ?>agent/dashboard/check_notification_count",  
                     method:"POST",  
                     data:{agent_id:agent_id},  
                     success:function(responce){ 
                        //  console.log(responce);
                        //  console.log('jjjjjjjjjjjjjjjjjjjj');
                         if(responce > 0)
                         {
                            $('#notification_count').append('<i class="fas fa-envelope mr-2"></i> '+responce+' Domestic Packages');
                            // $('#btn_agent').prop('disabled', true)
                             
                         }else
                         {
                             $('#notification_count').html('');
                            //  $('#btn_agent').prop('disabled', false)
                         } 
                     }  
                });  
           }  
      });  
 </script>

<script>  
 $(document).ready(function(){
  $("#notification_count").click(function() {  
 // var email = $('#agent_sess_id').val();  
           var agent_id = '0'; 
           //alert(email);
           if(agent_id != '')  
           {  
                $.ajax({  
                     url:"<?php echo base_url(); ?>agent/dashboard/enquiry_view",  
                     method:"POST",  
                     data:{agent_id:agent_id},  
                     success:function(responce){ 
                         if(responce = true)
                         {
                              // alert(responce);
                          // redirect($this->module_url_path.'agent/booking_enquiry/index');
                         }
                     }  
                });  
           } 
          }); 
      });  
 </script>


<script>  
 $(document).ready(function(){  
 // var email = $('#agent_sess_id').val();  
           var agent_id = '1'; 
           //alert(email);
           if(agent_id != '')  
           {  
                $.ajax({  
                     url:"<?php echo base_url(); ?>agent/dashboard/check_international_count",  
                     method:"POST",  
                     data:{agent_id:agent_id},  
                     success:function(responce){ 
                         if(responce > 0)
                         { 
                            $('#international_count').append('<i class="fas fa-users mr-2"></i> '+responce+' International Packages');
                            // $('#btn_agent').prop('disabled', true)
                             
                         }else
                         {
                             $('#international_count').html('');
                            //  $('#btn_agent').prop('disabled', false)
                         } 
                     }  
                });  
           }  
      });  
 </script>

<script>  
 $(document).ready(function(){
  $("#international_count").click(function() {  
 // var email = $('#agent_sess_id').val();  
           var agent_id = '1'; 
           //alert(email);
           if(agent_id != '')  
           {  
                $.ajax({  
                     url:"<?php echo base_url(); ?>agent/dashboard/international_view",  
                     method:"POST",  
                     data:{agent_id:agent_id},  
                     success:function(responce){ 
                         if(responce = true)
                         {
                          // redirect($this->module_url_path.'agent/booking_enquiry/index');
                          window.location.href = "<?=base_url()?>agent/international_booking_enquiry/index";
                         }
                     }  
                });  
           } 
          }); 
      });  
 </script>

<script type="text/javascript">  
     $(document).ready(function(){
          var login_count = $('#enquiry_login_count').val();
          if(login_count <=3){
               $("#agent_change_password").modal("show"); 
          }
     });

     
</script>

<script>
 $(document).ready(function(){
          $('.enq_id').click(function(event) {
             $("#enquiry_id").val($(this).attr("data-enq-id"))
          });
     });

</script>

<script>
 $(document).ready(function(){
          $('.international_enq_id').click(function(event) {
             $("#international_booking_enquiry_id").val($(this).attr("inter-data-enq-id"))
          });
     });

</script>

<!-- todays_domestic_notification_count -->
<!-- ===================================== -->

<script>  
 $(document).ready(function(){  
 // var email = $('#agent_sess_id').val();  
           var agent_id = '1'; 
           //alert(email);
           if(agent_id != '')  
           {  
                $.ajax({  
                     url:"<?php echo base_url(); ?>agent/dashboard/todays_domestic_notification_count",  
                     method:"POST",  
                     data:{agent_id:agent_id},  
                     success:function(responce){ 
                        //  console.log(responce);
                        //  console.log('jjjjjjjjjjjjjjjjjjjj');
                         if(responce > 0)
                         {
                            $('#todays_domestic_count').append('<i class="fas fa-envelope mr-2"></i> '+responce+' Todays Domestic Followup Enquiry');
                            // $('#btn_agent').prop('disabled', true)
                             
                         }else
                         {
                             $('#todays_domestic_count').html('<h6> No Enquiry </h6>');
                            //  $('#btn_agent').prop('disabled', false)
                         } 
                     }  
                });  
           }  
      });  
 </script>

<script>  
 $(document).ready(function(){
  $("#todays_domestic_count").click(function() {  
 // var email = $('#agent_sess_id').val();  
           var agent_id = '0'; 
           //alert(email);
           if(agent_id != '')  
           {  
                $.ajax({  
                     url:"<?php echo base_url(); ?>agent/dashboard/todays_enquiry_view",  
                     method:"POST",  
                     data:{agent_id:agent_id},  
                     success:function(responce){ 
                         if(responce = true)
                         {
                             window.location.href = "<?=base_url()?>agent/domestic_booking_enquiry_followup/index";
                         //  redirect($this->module_url_path.'agent/domestic_booking_enquiry_followup/index');
                         }
                     }  
                });  
           } 
          }); 
      });  
 </script>

<!-- =========================================== -->

<!-- ========international current date followup=================================== -->
<script>  
 $(document).ready(function(){  
 // var email = $('#agent_sess_id').val();  
           var agent_id = '1'; 
           //alert(email);
           if(agent_id != '')  
           {  
                $.ajax({  
                     url:"<?php echo base_url(); ?>agent/dashboard/todays_international_notification_count",  
                     method:"POST",  
                     data:{agent_id:agent_id},  
                     success:function(responce){ 
                        //  console.log(responce);
                        //  console.log('jjjjjjjjjjjjjjjjjjjj');
                         if(responce > 0)
                         {
                            $('#todays_international_count').append('<i class="fas fa-envelope mr-2"></i> '+responce+' Todays Inter Followup Enquiry');
                            // $('#btn_agent').prop('disabled', true)
                             
                         }else
                         {
                             $('#todays_international_count').html('<h6> No Enquiry </h6>');
                            //  $('#btn_agent').prop('disabled', false)
                         } 
                     }  
                });  
           }  
      });  
 </script>

<script>  
 $(document).ready(function(){
  $("#international_count").click(function() {  
 // var email = $('#agent_sess_id').val();  
           var agent_id = '0'; 
           //alert(email);
           if(agent_id != '')  
           {  
                $.ajax({  
                     url:"<?php echo base_url(); ?>agent/dashboard/todays_international_view",  
                     method:"POST",  
                     data:{agent_id:agent_id},  
                     success:function(responce){ 
                         if(responce = true)
                         {
                          window.location.href = "<?=base_url()?>agent/international_booking_enquiry_followup/index";
                         //  redirect($this->module_url_path.'agent/international_booking_enquiry_followup/index');
                         }
                     }  
                });  
           } 
          }); 
      });  
 </script>











<!-- Add Stationary request multiple at one time -->
<script>
    

        var i=1;
    $('#add_more').click(function() {
       // alert('hhhh');
            i++;
var structure = $('<div class="row" style="width:100% !important" id="new_row'+i+'">'+
                    '<div class="col-md-5">'+
                    '<div class="form-group">'+
                 '<label>Date:</label>'+
                    '<div class="input-group">'+
                        '<select name="stationary_name[]" class="form-control" id="stationary_name"> </select>'+
                   '</div>'+
                   '</div>'+
                     '</div>'+

                    '<div class="col-md-5">'+
                             '<div class="form-group">'+
                                '<label>Available Seats</label>'+
                                '<input type="number" class="form-control" name="stationary_qty[]" id="stationary_qty" placeholder="Enter Stationary Quantity">'+
                              '</div>'+
                      '</div>'+

                    '<div class="col-md-2 pt-4 d-flex justify-content-center align-self-center">'+
                        '<div class="form-group">'+
                        '<label></label>'+
                            '<button type="button" name="remove" id="'+i+'" class="btn btn-danger btn_remove">X</button>'+
                        '</div>'+
                    '</div>'+   
              '</div>');
$('#main_row').append(structure); 

});


$(document).on('click', '.btn_remove', function(){  
           var button_id = $(this).attr("id");   
           $('#new_row'+button_id+'').remove();  
      });

</script>
