<?php	
	$this->load->view("agent_inspector/layout/agent_inspector_header");
 	$this->load->view("agent_inspector/layout/agent_inspector_sidebar");
 	$this->load->view("agent_inspector/".$middle_content);
	 $this->load->view("agent_inspector/layout/agent_inspector_footer");
?>