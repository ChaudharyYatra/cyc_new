    <!-- banner starts -->
    <section class="banner overflow-hidden">
        <div class="slider top50">
            <div class="swiper-container">
                <div class="swiper-wrapper">
                    <?php foreach($sliders as $key => $sliders_value) { ?>
                    <div class="swiper-slide">
                        <div class="slide-inner">
                            
                            <div class="slide-image" style="background-image:url(<?php echo base_url(); ?>uploads/slider/<?php echo $sliders_value['image_name']; ?>)"></div>
                            <div class="swiper-content">
                                <div class="entry-meta mb-2">
                                    <h5 class="entry-category mb-0 white"><?php echo $sliders_value['title']; ?></h5>
                                </div>
                                <h1 class="mb-2"><a href="#" class="white"><?php echo $sliders_value['sub_title']; ?></a></h1>
                                <p class="white mb-4"><?php echo $sliders_value['description']; ?></p>
                            </div>
                            <div class="dot-overlay"></div>
                        </div> 
                    </div>
                    <?php } ?>
                   
                </div>
            </div>
        </div>
        <!-- Add Arrows -->
        <div class="swiper-button-next"></div>
        <div class="swiper-button-prev"></div>
    </section>
    <!-- banner ends -->

    <!-- form main starts -->
    <div class="form-main">
        <div class="section-shape top-0" style="background-image: url(<?php echo base_url(); ?>assets/front/images/shape-pat.png);"></div>
        <div class="container">
            <div class="row align-items-center form-content rounded position-relative ms-5 me-5">
                <div class="col-lg-2 p-0">
                    <h4 class="form-title form-title1 text-center p-4 py-5 white bg-theme mb-0 rounded-start d-lg-flex align-items-center"><i class="icon-location-pin fs-1 me-1"></i> Find Your Holidays</h4>
                </div>
                <div class="col-lg-10 px-4">
                    <form action="<?php echo base_url();?>home/all_packages_search" method="post">
                    <div class="form-content-in d-lg-flex align-items-center">
                        <div class="form-group me-2">
                            <div class="input-box">
                                <select class="niceSelect" name="destination_name">
                                    <option value="">Select Destination</option>
                                    <?php foreach($main_packages as $pack_data){  ?>
                                    <option value="<?php echo $pack_data['tour_title'];?>"><?php echo $pack_data['tour_title'];?></option>
                                    <?php } ?>
                                </select>
                            </div>                            
                        </div>
                        <!--<div class="form-group me-2">-->
                        <!--    <div class="input-box">-->
                        <!--        <input type="date" name="tour_date">-->
                        <!--    </div>                            -->
                        <!--</div>-->
                       
                        <!--<div class="form-group me-2">-->
                        <!--    <div class="input-box">-->
                        <!--        <select class="niceSelect" name="duration">-->
                        <!--            <option value="">Tour Duration</option>-->
                        <!--            <?php //foreach($main_packages as $pack_data){  ?>-->
                        <!--            <option value="<?php //echo $pack_data['tour_number_of_days'];?>"><?php //echo $pack_data['tour_number_of_days'];?> Days</option>-->
                        <!--            <?php //} ?>-->
                        <!--        </select>-->
                        <!--    </div>                             -->
                        <!--</div>-->
                        <div class="form-group mb-0 text-center">
                            <input type="submit" class="nir-btn w-100" id="submit" value="Search Now" name="submit" style="width:20px">
                        </div>
                    </div>

                    </form>
                </div>
                <!--<div class="col-lg-10 px-4">-->
                <!--    <div class="form-content-in d-lg-flex align-items-center">-->
                <!--        <div class="form-group me-2">-->
                <!--            <div class="input-box">-->
                <!--                <select class="niceSelect">-->
                <!--                    <option value="1">Destination</option>-->
                <!--                    <option value="2">Argentina</option>-->
                <!--                    <option value="3">Belgium</option>-->
                <!--                    <option value="4">Canada</option>-->
                <!--                    <option value="5">Denmark</option>-->
                <!--                </select>-->
                <!--            </div>                            -->
                <!--        </div>-->
                <!--        <div class="form-group me-2">-->
                <!--            <div class="input-box">-->
                <!--                <input type="date" name="date">-->
                <!--            </div>                            -->
                <!--        </div>-->
                <!--        <div class="form-group me-2">-->
                <!--            <div class="input-box">-->
                <!--                <select class="niceSelect">-->
                <!--                    <option value="1">Travel Type</option>-->
                <!--                    <option value="2">City Tour</option>-->
                <!--                    <option value="3">Family Tour</option>-->
                <!--                </select>-->
                <!--            </div>                             -->
                <!--        </div>-->
                <!--        <div class="form-group me-2">-->
                <!--            <div class="input-box">-->
                <!--                <select class="niceSelect">-->
                <!--                    <option value="1">Tour Duration</option>-->
                <!--                    <option value="2">5 days</option>-->
                <!--                    <option value="3">7 Days</option>-->
                <!--                </select>-->
                <!--            </div>                             -->
                <!--        </div>-->
                <!--        <div class="form-group mb-0 text-center">-->
                <!--            <a href="#" class="nir-btn w-100"><i class="fa fa-search mr-2"></i> Search Now</a>-->
                <!--        </div>-->
                <!--    </div>-->
                <!--</div>-->
            </div>
        </div>
    </div>
    <!-- form main ends -->

<?php foreach($core_features as $key => $core_features_value) { ?>
    <!-- about-us starts -->
    <section class="about-us pb-6 pt-10" style="background-image:url(<?php echo base_url(); ?>assets/front/images/shape4.png); background-position:center;">
        <div class="container">
            
            <div class="section-title mb-6 w-50 mx-auto text-center">
                <h4 class="mb-1 theme1">Core Features</h4>
                <h2 class="mb-1">Find <span class="theme">Travel Perfection</span></h2>
            </div>

            <!-- why us starts -->
            <div class="why-us">
                <div class="why-us-box">
                    <div class="row">
                        <div class="col-lg-3 col-md-6 col-sm-6 mb-4">
                            <div class="why-us-item p-5 pt-6 pb-6 border rounded bg-white h-100">
                                <div class="why-us-content">
                                    <div class="why-us-icon mb-1">
                                        <i class="fa fa-h-square theme" style="font-size:48px;"></i>
                                    </div>
                                    <h4><?php echo $core_features_value['feature_one_title']; ?></h4>
                                    <p class="mb-2"><?php echo $core_features_value['feature_one_description']; ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-6 mb-4">
                            <div class="why-us-item p-5 pt-6 pb-6 border rounded bg-white h-100">
                                <div class="why-us-content">
                                    <div class="why-us-icon mb-1">
                                        <i class="fa fa-plane theme" style="font-size:48px;"></i>
                                    </div>
                                    <h4><?php echo $core_features_value['feature_two_title']; ?></h4>
                                    <p class="mb-2"><?php echo $core_features_value['feature_two_description']; ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-6 mb-4">
                            <div class="why-us-item p-5 pt-6 pb-6 border rounded bg-white h-100">
                                <div class="why-us-content">
                                    <div class="why-us-icon mb-1">
                                        <i class="fas fa-hamburger theme" style="font-size:48px;"></i>
                                    </div>
                                    <h4><?php echo $core_features_value['feature_three_title']; ?></h4>
                                    <p class="mb-2"><?php echo $core_features_value['feature_three_description']; ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-6 mb-4">
                            <div class="why-us-item p-5 pt-6 pb-6 border rounded bg-white h-100">
                                <div class="why-us-content">
                                    <div class="why-us-icon mb-1">
                                        <i class="fa fa-user theme" style="font-size:48px;"></i>
                                    </div>
                                    <h4><?php echo $core_features_value['feature_four_title']; ?></h4>
                                    <p class="mb-2"><?php echo $core_features_value['feature_four_description']; ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- why us ends -->
        </div>
        <div class="white-overlay"></div>
    </section>
    <!-- about-us ends -->
<?php } ?>
    <!-- top Destination starts -->
    <section class="trending pb-3 pt-0">
        <div class="container">
            <div class="section-title mb-6 w-50 mx-auto text-center">
                <h4 class="mb-1 theme1">International Destinations</h4>
                <h2 class="mb-1">Explore <span class="theme">International Destinations</span></h2>
               
            </div>
            <div class="row align-items-center">
                <div class="row item-slider">
                    <?php if(count($international_packages)>0) { foreach($international_packages as $key => $international_packages_value) { ?>
                    <div class="col-lg-4 col-md-6 col-sm-6 mb-4">
                        <div class="trend-item rounded box-shadow bg-white">
                            <div class="trend-image position-relative">
                                <img src="<?php echo base_url(); ?>uploads/international_packages/<?php echo $international_packages_value['image_name']; ?>" alt="<?php echo $international_packages_value['image_name']; ?>" height="300px">
                                <div class="color-overlay"></div>
                            </div>
                            <div class="trend-content p-4 pt-5 position-relative">
                                <div class="trend-meta bg-theme white px-3 py-2 rounded">
                                    <div class="entry-author">
                                        <i class="icon-calendar"></i>
                                        <span class="fw-bold"> <?php echo $international_packages_value['tour_number_of_days']; ?></span>
                                    </div>
                                </div>
                               <h5 class="theme mb-1">Tour Number: <?php echo $international_packages_value['tour_number']; ?></h5>
                                <h3 class="mb-1"><a href="<?php echo base_url(); ?>international_packages/package_details/<?php echo $international_packages_value['id']; ?>"><?php echo mb_substr($international_packages_value['tour_title'], 0, 35); ?></a></h3>
                                <div class="rating-main d-flex align-items-center pb-2">
                                    
                                    <div class="rating">
                                        <?php if($international_packages_value['rating']=='1') { ?>
                                        <span class="fa fa-star checked"></span>
                                        <?php }
                                        if($international_packages_value['rating']=='2') {
                                        ?>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <?php }
                                        if($international_packages_value['rating']=='3') {
                                        ?>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <?php }
                                        if($international_packages_value['rating']=='4') {
                                        ?>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <?php }
                                        if($international_packages_value['rating']=='5') {
                                        ?>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <?php } ?>
                                    </div>
                                </div>
                                <p class=" border-b pb-2 mb-2"><?php echo mb_substr($international_packages_value['short_description'], 0, 70); ?></p>
                                <div class="entry-meta">
                                    <div class="entry-author d-flex align-items-center">
                                        <p class="mb-0">Starting from<span class="theme fw-bold fs-5"> <i class="fa fa-inr" aria-hidden="true"></i> <?php echo $international_packages_value['cost']; ?></span></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php } } ?>
                   
                </div>
                <!--<div class="col-lg-7">-->
                <!--    <div class="row">-->
                <!--        <div class="col-lg-12 mb-4">-->
                <!--            <div class="trend-item1">-->
                <!--                <div class="trend-image position-relative rounded">-->
                <!--                    <img src="<?php echo base_url(); ?>uploads/do_not_delete/Caspian_Valley.png" alt="image">-->
                <!--                    <div class="trend-content d-flex align-items-center justify-content-between position-absolute bottom-0 p-4 w-100 z-index">-->
                <!--                        <div class="trend-content-title">-->
                <!--                            <h5 class="mb-0"><p class="theme1">Italy</p></h5>-->
                <!--                            <h3 class="mb-0 white">Caspian Valley</h3>-->
                <!--                        </div>-->
                <!--                        <span class="white bg-theme p-1 px-2 rounded">18 Tours</span>-->
                <!--                    </div>-->
                <!--                    <div class="color-overlay"></div>-->
                <!--                </div>-->
                <!--            </div>-->
                <!--        </div>-->
                <!--        <div class="col-lg-6 col-md-6 col-sm-6 mb-4">-->
                <!--            <div class="trend-item1">-->
                <!--                <div class="trend-image position-relative rounded">-->
                <!--                    <img src="<?php echo base_url(); ?>uploads/do_not_delete/Russia.png" alt="image">-->
                <!--                    <div class="trend-content d-flex align-items-center justify-content-between position-absolute bottom-0 p-4 w-100">-->
                <!--                        <div class="trend-content-title">-->
                <!--                            <h5 class="mb-0"><p class="theme1">Moscow</p></h5>-->
                <!--                            <h3 class="mb-0 white">Russia</h3>-->
                <!--                        </div>-->
                <!--                        <span class="white bg-theme p-1 px-2 rounded">15 Tours</span>-->
                <!--                    </div>-->
                <!--                    <div class="color-overlay"></div>-->
                <!--                </div>-->
                <!--            </div>-->
                <!--        </div>-->
                <!--        <div class="col-lg-6 col-md-6 col-sm-6 mb-4">-->
                <!--            <div class="trend-item1">-->
                <!--                <div class="trend-image position-relative rounded">-->
                <!--                    <img src="<?php echo base_url(); ?>uploads/do_not_delete/America.png" alt="image">-->
                <!--                    <div class="trend-content d-flex align-items-center justify-content-between position-absolute bottom-0 p-4 w-100 z-index">-->
                <!--                        <div class="trend-content-title">-->
                <!--                            <h5 class="mb-0"><p class="theme1">Florida</p></h5>-->
                <!--                            <h3 class="mb-0 white">America</h3>-->
                <!--                        </div>-->
                <!--                        <span class="white bg-theme p-1 px-2 rounded">32 Tours</span>-->
                <!--                    </div>-->
                <!--                    <div class="color-overlay"></div>-->
                <!--                </div>-->
                <!--            </div>-->
                <!--        </div>-->
                <!--    </div>-->
                <!--</div>-->
                <!--<div class="col-lg-5 mb-4">-->
                <!--    <div class="trend-item1">-->
                <!--        <div class="trend-image position-relative rounded">-->
                <!--            <img src="<?php echo base_url(); ?>uploads/do_not_delete/London.png" alt="image">-->
                <!--            <div class="trend-content d-flex align-items-center justify-content-between position-absolute bottom-0 p-4 w-100 z-index">-->
                <!--                <div class="trend-content-title">-->
                <!--                    <h5 class="mb-0"><p class="theme1">England</p></h5>-->
                <!--                    <h3 class="mb-0 white">London</h3>-->
                <!--                </div>-->
                <!--                <span class="white bg-theme p-1 px-2 rounded">15 Tours</span>-->
                <!--            </div>-->
                <!--            <div class="color-overlay"></div>-->
                <!--        </div>-->
                <!--    </div>-->
                <!--</div>-->
            </div>
        </div>
    </section>
    <!-- top Destination ends -->

    <!-- best tour Starts -->
    <section class="trending bg-grey pt-17 pb-6">
        <div class="section-shape top-0" style="background-image: url(<?php echo base_url(); ?>assets/front/images/shape8.png);"></div>
        <div class="container">
            <div class="row align-items-center justify-content-between mb-6 ">
                <div class="col-lg-7">
                    <div class="section-title text-center text-lg-start">
                        <h4 class="mb-1 theme1">Top Pick</h4>
                        <h2 class="mb-1">Best <span class="theme">Tour Packages</span></h2>
                    </div>
                </div>
                <div class="col-lg-5">  
                </div>
            </div>
            <div class="trend-box">
                <div class="row item-slider">
                    <?php  
                   foreach($main_packages as $key => $main_packages_value) { ?>
                    <div class="col-lg-4 col-md-6 col-sm-6 mb-4">
                        <div class="trend-item rounded box-shadow bg-white">
                            <div class="trend-image position-relative">
                                <img src="<?php echo base_url(); ?>uploads/packages/<?php echo $main_packages_value['image_name']; ?>" alt="<?php echo $main_packages_value['image_name']; ?>" height="300px">
                                <div class="color-overlay"></div>
                            </div>
                            <div class="trend-content p-4 pt-5 position-relative">
                                <div class="trend-meta bg-theme white px-3 py-2 rounded">
                                    <div class="entry-author">
                                        <i class="icon-calendar"></i>
                                        <span class="fw-bold"> <?php echo $main_packages_value['tour_number_of_days']; ?></span>
                                    </div>
                                </div>
                               <h5 class="theme mb-1">Tour Number: <?php echo $main_packages_value['tour_number']; ?></h5>
                                <h3 class="mb-1"><a href="<?php echo base_url(); ?>packages/package_details/<?php echo $main_packages_value['id']; ?>"><?php echo mb_substr($main_packages_value['tour_title'], 0, 35); ?></a></h3>
                                <div class="rating-main d-flex align-items-center pb-2">
                                    <div class="rating">
                                        <?php if($main_packages_value['rating']=='1') { ?>
                                        <span class="fa fa-star checked"></span>
                                        <?php }
                                        if($main_packages_value['rating']=='2') {
                                        ?>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <?php }
                                        if($main_packages_value['rating']=='3') {
                                        ?>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <?php }
                                        if($main_packages_value['rating']=='4') {
                                        ?>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <?php }
                                        if($main_packages_value['rating']=='5') {
                                        ?>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <?php } ?>
                                    </div>
                                </div>
                                <p class=" border-b pb-2 mb-2"><?php echo mb_substr($main_packages_value['short_description'], 0, 70); ?></p>
                                <div class="entry-meta">
                                    <div class="entry-author d-flex align-items-center">
                                        <p class="mb-0">Starting from<span class="theme fw-bold fs-5"> <i class="fa fa-inr" aria-hidden="true"></i> <?php echo $main_packages_value['cost']; ?></span></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php } ?>
                   
                </div>
            </div>  
           
        </div>
    </section>
    <!-- best tour Ends -->

    <!-- Last Minute Deal Starts -->
    <section class="trending pb-9">
        <div class="container">
            <div class="section-title mb-6 w-75 mx-auto text-center">
                <h4 class="mb-1 theme1">Top Packages</h4>
                <h2 class="mb-1">The Best <span class="theme">Tour Packages</span></h2>
                
            </div>  
            <div class="trend-box">
                <div class="row">
                    <?php foreach($top_packages as $key => $top_packages_value) { ?>
                        <div class="col-lg-4 mb-4">
                        <div class="trend-item1 rounded box-shadow bg-white">
                            <div class="trend-image position-relative">
                                <img src="<?php echo base_url(); ?>uploads/packages/<?php echo $top_packages_value['image_name']; ?>" alt="<?php echo $top_packages_value['image_name']; ?>" height="300px">
                                <div class="trend-content1 p-4">
                                    <h5 class="theme mb-1">Tour Number: <?php echo $top_packages_value['tour_number']; ?></h5>
                                    <h3 class="mb-1 white"><a href="<?php echo base_url(); ?>packages/package_details/<?php echo $top_packages_value['id']; ?>" class="white"><?php echo mb_substr($top_packages_value['tour_title'], 0, 35); ?></a></h3>
                                    <div class="rating-main d-flex align-items-center pb-2">
                                        <div class="rating">
                                            <?php if($top_packages_value['rating']=='1') { ?>
                                        <span class="fa fa-star checked"></span>
                                        <?php }
                                        if($top_packages_value['rating']=='2') {
                                        ?>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <?php }
                                        if($top_packages_value['rating']=='3') {
                                        ?>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <?php }
                                        if($top_packages_value['rating']=='4') {
                                        ?>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <?php }
                                        if($top_packages_value['rating']=='5') {
                                        ?>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <?php } ?>
                                        </div>
                                        <!--<span class="ms-2 white">(16)</span>-->
                                    </div>
                                    <div class="entry-meta d-flex align-items-center justify-content-between">
                                        <div class="entry-author d-flex align-items-center">
                                            <p class="mb-0 white">Starting from <i class="fa fa-inr" aria-hidden="true"></i><span class="theme1 fw-bold fs-5"> <?php echo $top_packages_value['cost']; ?></span></p>
                                        </div>
                                        <div class="entry-author">
                                            <i class="icon-calendar white"></i>
                                            <span class="fw-bold white"> <?php echo $top_packages_value['tour_number_of_days']; ?></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="overlay"></div>
                            </div>
                        </div>
                    </div>
                    <?php } ?>
                    <div class="col-lg-12 text-center">
                        <a href="<?php echo base_url(); ?>packages/all_packages" class="nir-btn">View All Packages</a>
                    </div>
                </div>
            </div>    
        </div>
    </section>
    <!-- Last Minute Deal Ends -->

    <!-- testimonial starts -->
    <section class="testimonial pt-10 pb-20"  style="background-image: url(<?php echo base_url(); ?>uploads/do_not_delete/Good_Reviews.png);">   
        <div class="container">
            <div class="testimonial-in">
                <div class="row align-items-center">
                    <div class="col-lg-5">
                        <div class="section-title">
                            <h4 class="mb-1 theme1">Our Testimonails</h4>
                            <h2 class="mb-1 white">Good Reviews By <span class="theme">Clients</span></h2>
                            <p class="mb-0 white">Reviews given by our clients about their tours.</p>
                        </div>
                    </div>
                    <div class="col-lg-7">
                        <div class="row about-slider">
                            <?php if(count($client_reviews)>0) { foreach($client_reviews as $key => $client_reviews_value) { ?>
                            <div class="col-sm-4 item">
                                <div class="testimonial-item1">
                                    <div class="details d-flex">
                                        <i class="fa fa-quote-left fs-1 mb-0"></i>
                                        <div class="author-content ms-4">
                                            <p class="mb-4 white fs-5 fw-normal"><?php echo $client_reviews_value['review']; ?></p>
                                            
                                            <div class="author-info d-flex align-items-center">
                                                <img src="<?php echo base_url(); ?>uploads/client_reviews/<?php echo $client_reviews_value['image_name']; ?>" alt="<?php echo $client_reviews_value['name']; ?>">
                                                <div class="author-title ms-3">
                                                    <h5 class="m-0 theme1"><?php echo $client_reviews_value['name']; ?></h5>
                                                    <span class="white"><?php echo $client_reviews_value['designation']; ?></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php } } ?>
                        </div>
                    </div>
                </div>
            </div> 
        </div> 

        <div class="dot-overlay"></div>   
    </section>
    <!-- testimonial Ends -->

    <!-- offer Packages Starts -->
    <section class="trending trend-packages pt-0 pb-0 z-index3">
        <div class="container">
            <div class="trend-box mt-minus">
                <div class="row review-slider1 mx-0">
                    <?php if(count($random_packages)>0) { foreach($random_packages as $key => $random_packages_value) { ?>
                    <div class="col-lg-6 px-2">
                        <div class="trend-full bg-white rounded box-shadow overflow-hidden">
                            <div class="row m-0">
                               
                                <div class="col-lg-12 col-md-12">
                                    <div class="trend-content py-3 position-relative">
                                        <h5 class="theme mb-1">Tour Number: <?php echo $random_packages_value['tour_number']; ?></h5>
                                        <h3 class="mb-1"><a href="<?php echo base_url(); ?>packages/package_details/<?php echo $random_packages_value['id']; ?>"><?php echo $random_packages_value['tour_title']; ?></a></h3>
                                        <div class="rating-main d-flex align-items-center pb-2">
                                            <div class="rating">
                                                 <?php if($random_packages_value['rating']=='1') { ?>
                                        <span class="fa fa-star checked"></span>
                                        <?php }
                                        if($random_packages_value['rating']=='2') {
                                        ?>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <?php }
                                        if($random_packages_value['rating']=='3') {
                                        ?>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <?php }
                                        if($random_packages_value['rating']=='4') {
                                        ?>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <?php }
                                        if($random_packages_value['rating']=='5') {
                                        ?>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <?php } ?>
                                            </div>
                                           
                                        </div>
                                        <p><?php echo mb_substr($random_packages_value['short_description'], 0, 70); ?> </p>
                                        <div class="trend-meta border-b pb-2 mb-2">
                                            <div class="entry-author theme">
                                                <i class="icon-calendar"></i>
                                                <span> <?php echo $random_packages_value['tour_number_of_days']; ?></span>
                                            </div>
                                        </div>
                                        <div class="entry-meta">
                                            <div class="entry-author d-flex align-items-center">
                                                <p class="mb-0">Starting from <i class="fa fa-inr" aria-hidden="true"></i><span class="theme fw-bold fs-5"> <?php echo $random_packages_value['cost']; ?></span></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                    <?php } } ?>
                </div>
            </div>    
        </div>
    </section>
    <!-- offer Packages Ends -->

    <!-- our teams starts -->
    <section class="our-team pb-0">
        <div class="container">
              
            <div class="section-title mb-6 w-75 mx-auto text-center">
                <h4 class="mb-1 theme1">Tour Guides</h4>
                <h2 class="mb-1">Meet Our <span class="theme">Excellent Guides</span></h2>
                <p>A person who shows the way to others.</p>
            </div>  
            <div class="team-main">
                <div class="row shop-slider">
                    <?php if(count($tour_guides)>0) { foreach($tour_guides as $key => $tour_guides_value) { ?>
                    <div class="col-lg-3 col-md-6 col-sm-12 mb-4">
                        <div class="team-list rounded">
                            <div class="team-image">
                                <img src="<?php echo base_url(); ?>uploads/tour_guides/<?php echo $tour_guides_value['image_name']; ?>" alt="<?php echo $tour_guides_value['name']; ?>">
                            </div>
                            <div class="team-content text-center p-3 bg-theme">
                               <h4 class="mb-0 white"><?php echo $tour_guides_value['name']; ?></h4>
                                <p class="mb-0 white"><?php echo $tour_guides_value['designation']; ?></p>
                            </div>
                        </div>
                    </div>
                    <?php } } ?>
                </div>
            </div>
        </div>
    </section>
    <!-- our teams Ends -->

    <!-- partner starts -->
    <!--<section class="our-partner pt-0 pb-5">-->
    <!--    <div class="container">-->
    <!--        <div class="section-title mb-6 w-75 mx-auto text-center">-->
    <!--            <h4 class="mb-1 theme1">Our Partners</h4>-->
    <!--            <h2 class="mb-1">Our Awesome <span class="theme">partners</span></h2>-->
    <!--            <p>Shake hands for move ahead.</p>-->
    <!--        </div>-->
    <!--        <div class="row align-items-center partner-in partner-slider">-->
    <!--            <div class="col-md-3 col-sm-6">-->
    <!--                <div class="partner-item p-4 py-2 rounded bg-lgrey">-->
    <!--                    <img src="<?php echo base_url(); ?>assets/front/images/cl-1.png" alt="">-->
    <!--                </div>-->
    <!--            </div>-->
    <!--            <div class="col-md-3 col-sm-6">-->
    <!--                <div class="partner-item p-4 py-2 rounded bg-lgrey">-->
    <!--                    <img src="<?php echo base_url(); ?>assets/front/images/cl-5.png" alt="">-->
    <!--                </div>-->
    <!--            </div>-->
    <!--            <div class="col-md-3 col-sm-6">-->
    <!--                <div class="partner-item p-4 py-2 rounded bg-lgrey">-->
    <!--                    <img src="<?php echo base_url(); ?>assets/front/images/cl-2.png" alt="">-->
    <!--                </div>-->
    <!--            </div>-->
    <!--            <div class="col-md-3 col-sm-6">-->
    <!--                <div class="partner-item p-4 py-2 rounded bg-lgrey">-->
    <!--                    <img src="<?php echo base_url(); ?>assets/front/images/cl-3.png" alt="">-->
    <!--                </div>-->
    <!--            </div>-->
    <!--            <div class="col-md-3 col-sm-6">-->
    <!--                <div class="partner-item p-4 py-2 rounded bg-lgrey">-->
    <!--                    <img src="<?php echo base_url(); ?>assets/front/images/cl-4.png" alt="">-->
    <!--                </div>-->
    <!--            </div>-->
    <!--            <div class="col-md-3 col-sm-6">-->
    <!--                <div class="partner-item p-4 py-2 rounded bg-lgrey">-->
    <!--                    <img src="<?php echo base_url(); ?>assets/front/images/cl-5.png" alt="">-->
    <!--                </div>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</section>-->
    <!-- partner ends -->


 