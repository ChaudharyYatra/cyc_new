<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="zxx">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Travelin - Travel Tour Booking HTML Templates</title>
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="images/favicon.png">
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <!--Custom CSS-->
    <link href="css/style.css" rel="stylesheet" type="text/css">
    <!--Plugin CSS-->
    <link href="css/plugin.css" rel="stylesheet" type="text/css">

    <!--Font Awesome-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.min.css">

    <link rel="stylesheet" href="fonts/line-icons.css" type="text/css">
</head>

<body style="background-image:url(images/bg/bg1.jpg);">

    <!-- search banner starts -->
    <section class="search-banner d-flex align-items-center pt-14 pb-10">
        <div class="container">
            <div class="search-banner-in">
                <div class="row align-items-center">
                    <div class="col=-lg-12 mb-10 text-center">
                        <img src="images/logo.png" alt="image" class="bg-white rounded p-4 box-shadow">
                    </div>
                    <div class="col-lg-6 pe-4 mb-4">
                         <div class="section-title mb-10 text-lg-start text-center">
                             <h4 class="white text-uppercase">Are you ready to travel</h4>
                            <h1 class="text-uppercase white">ultimate travel <span class="theme1">tour booking</span></h1>
                         </div>
                         <div class="trending-topic-main">
                            <!-- tab navs -->
                            <ul class="nav nav-tabs nav-pills nav-fill bg-transparent mb-0" id="postsTab1" role="tablist">
                                <li class="nav-item" role="presentation">
                                    <button  aria-selected="false" class="nav-link active white" data-bs-target="#tour" data-bs-toggle="tab" id="tour-tab" role="tab" type="button"><i class="icon-umbrella fs-1 mb-1 d-block"></i> Tour</button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button aria-selected="true" class="nav-link white" data-bs-target="#flight" data-bs-toggle="tab" id="flight-tab" role="tab" type="button"><i class="icon-plane fs-1 mb-1 d-block"></i> Flight</button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button aria-selected="true" class="nav-link white" data-bs-target="#hotel" data-bs-toggle="tab" id="hotel-tab" role="tab" type="button"><i class="icon-home fs-1 d-block mb-1"></i> Hotel</button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button aria-selected="true" class="nav-link white" data-bs-target="#cruise" data-bs-toggle="tab" id="cruise-tab" role="tab" type="button"><i class="icon-speedometer fs-1 mb-1 d-block"></i> Cruise</button>
                                </li>
                            </ul>
                            <!-- tab contents -->
                            <div class="tab-content pt-4" id="postsTabContent1">
                                <!-- tour posts -->
                                <div aria-labelledby="tour-tab" class="tab-pane fade active show" id="tour" role="tabpanel">
                                    <div class="book-form">
                                        <div class="row d-flex align-items-center justify-content-between">
                                            <div class="col-lg-6 mb-2">
                                                <div class="form-group">
                                                    <div class="input-box">
                                                        <label class="white">Your Destination</label>
                                                        <select class="niceSelect">
                                                            <option value="1">Destination</option>
                                                            <option value="2">Argentina</option>
                                                            <option value="3">Belgium</option>
                                                            <option value="4">Canada</option>
                                                            <option value="5">Denmark</option>
                                                        </select>
                                                    </div>                            
                                                </div>
                                            </div>
                                            <div class="col-lg-6 mb-2">
                                                <div class="form-group">
                                                    <div class="input-box">
                                                        <label class="white">Depart Date</label>
                                                        <input type="date" name="date">
                                                    </div>                            
                                                </div>
                                            </div>
                                            <div class="col-lg-6 mb-2">
                                                <div class="form-group">
                                                    <div class="input-box">
                                                        <label class="white">Travel Type</label>
                                                        <select class="niceSelect">
                                                            <option value="1">Historical Tour</option>
                                                            <option value="2">City Tour</option>
                                                            <option value="3">Family Tour</option>
                                                        </select>
                                                    </div>                             
                                                </div>
                                            </div>
                                            <div class="col-lg-6 mb-4">
                                                <div class="form-group">
                                                    <div class="input-box">
                                                        <label class="white">Tour Duration</label>
                                                        <select class="niceSelect">
                                                            <option value="1">3 Days</option>
                                                            <option value="2">5 days</option>
                                                            <option value="3">7 Days</option>
                                                        </select>
                                                    </div>                             
                                                </div>
                                            </div>
                                            <div class="col-lg-12">
                                                <div class="form-group mb-0 text-center">
                                                    <a href="#" class="nir-btn"><i class="fa fa-search mr-2"></i> Search Now</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- flight posts -->
                                <div aria-labelledby="flight-tab" class="tab-pane fade" id="flight" role="tabpanel">
                                    <div class="book-form">
                                        <div class="row d-flex align-items-center justify-content-between">
                                            <div class="col-lg-6 mb-2">
                                                <div class="form-group">
                                                    <div class="input-box">
                                                        <label class="white">Flying From</label>
                                                        <select class="niceSelect">
                                                            <option value="1">Where are you goings</option>
                                                            <option value="2">Argentina</option>
                                                            <option value="3">Belgium</option>
                                                            <option value="4">Canada</option>
                                                            <option value="5">Denmark</option>
                                                        </select>
                                                    </div>                            
                                                </div>
                                            </div>
                                            <div class="col-lg-6 mb-2">
                                                <div class="form-group">
                                                    <div class="input-box">
                                                        <label class="white">Flying To</label>
                                                        <select class="niceSelect">
                                                            <option value="1">Where are you goings</option>
                                                            <option value="2">Argentina</option>
                                                            <option value="3">Belgium</option>
                                                            <option value="4">Canada</option>
                                                            <option value="5">Denmark</option>
                                                        </select>
                                                    </div>                            
                                                </div>
                                            </div>
                                            <div class="col-lg-12 mb-2">
                                                <div class="form-group">
                                                    <div class="input-box">
                                                        <label class="white">Depart Date</label>
                                                        <input type="date" name="date1">
                                                    </div>                            
                                                </div>
                                            </div>
                                            <div class="col-lg-6 mb-2">
                                                <div class="form-group">
                                                    <div class="input-box">
                                                        <label class="white">Class Type</label>
                                                        <select class="niceSelect">
                                                            <option value="1">Premium</option>
                                                            <option value="2">Classic</option>
                                                        </select>
                                                    </div>                             
                                                </div>
                                            </div>
                                            <div class="col-lg-6 mb-4">
                                                <div class="form-group">
                                                    <div class="input-box">
                                                        <label class="white">Person</label>
                                                        <select class="niceSelect">
                                                            <option value="1">1</option>
                                                            <option value="2">2</option>
                                                            <option value="3">3</option>
                                                        </select>
                                                    </div>                             
                                                </div>
                                            </div>
                                            <div class="col-lg-12">
                                                <div class="form-group mb-0 text-center">
                                                    <a href="#" class="nir-btn"><i class="fa fa-search mr-2"></i> Search Now</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- hotel posts -->
                                <div aria-labelledby="hotel-tab" class="tab-pane fade" id="hotel" role="tabpanel">
                                    <div class="book-form">
                                        <div class="row d-flex align-items-center justify-content-between">
                                            <div class="col-lg-12 mb-2">
                                                <div class="form-group">
                                                    <div class="input-box">
                                                        <label class="white">Your Destination</label>
                                                        <select class="niceSelect">
                                                            <option value="1">Where are you goings</option>
                                                            <option value="2">Argentina</option>
                                                            <option value="3">Belgium</option>
                                                            <option value="4">Canada</option>
                                                            <option value="5">Denmark</option>
                                                        </select>
                                                    </div>                            
                                                </div>
                                            </div>
                                            <div class="col-lg-6 mb-2">
                                                <div class="form-group">
                                                    <div class="input-box">
                                                        <label class="white">Check In</label>
                                                        <input type="date" name="date2">
                                                    </div>                            
                                                </div>
                                            </div>
                                            <div class="col-lg-6 mb-2">
                                                <div class="form-group">
                                                    <div class="input-box">
                                                        <label class="white">Check Out</label>
                                                        <input type="date" name="date3">
                                                    </div>                            
                                                </div>
                                            </div>
                                            <div class="col-lg-6 mb-2">
                                                <div class="form-group">
                                                    <div class="input-box">
                                                        <label class="white">Room Type</label>
                                                        <select class="niceSelect">
                                                            <option value="1">Premium</option>
                                                            <option value="2">Classic</option>
                                                        </select>
                                                    </div>                             
                                                </div>
                                            </div>
                                            <div class="col-lg-6 mb-4">
                                                <div class="form-group">
                                                    <div class="input-box">
                                                        <label class="white">Person</label>
                                                        <select class="niceSelect">
                                                            <option value="1">1</option>
                                                            <option value="2">2</option>
                                                            <option value="3">3</option>
                                                        </select>
                                                    </div>                             
                                                </div>
                                            </div>
                                            <div class="col-lg-12">
                                                <div class="form-group mb-0 text-center">
                                                    <a href="#" class="nir-btn"><i class="fa fa-search mr-2"></i> Search Now</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 ps-4 mb-4">
                        <div class="search-banner-list">
                            <div class="search-banner-item d-flex align-items-center border-b mb-4 pb-4">
                                <i class="fas fa-umbrella-beach p-4 rounded bg-theme lh-base white fs-1"></i>
                                <div class="search-banner-item-ctn ms-4 w-75">
                                    <h3 class="theme1">Many Choices</h3>
                                    <p class="mb-0 white">Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident.</p>
                                </div>
                            </div>

                            <div class="search-banner-item d-flex align-items-center border-b mb-4 pb-4">
                                <i class="fas fa-luggage-cart p-4 rounded bg-theme lh-base white fs-1"></i>
                                <div class="search-banner-item-ctn ms-4 w-75">
                                    <h3 class="theme1">Pick Up & Go</h3>
                                    <p class="mb-0 white">Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident.</p>
                                </div>
                            </div>
                            <div class="search-banner-item d-flex align-items-center">
                                <i class="fas fa-briefcase p-4 rounded bg-theme lh-base white fs-1 text-center"></i>
                                <div class="search-banner-item-ctn ms-4 w-75">
                                    <h3 class="theme1">Best Prices</h3>
                                    <p class="mb-0 white">Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="dot-overlay"></div>
        <div id="particles-js" class="zindex3"></div>
    </section>
    <!-- search banner Ends -->

    <!-- footer starts -->
    <div class="footer-copyright bg-title">
        <div class="container">
            <div class="copyright-inner rounded pt-3 d-md-flex align-items-center justify-content-between text-center">
                <div class="copyright-text mb-3">
                    <p class="m-0 white">2022 Travelin. All rights reserved.</p>
                </div>
                <div class="social-links mb-3">
                    <ul>  
                        <li><a href="#"><i class="fab fa-facebook" aria-hidden="true"></i></a></li>
                        <li><a href="#"><i class="fab fa-twitter" aria-hidden="true"></i></a></li>
                        <li><a href="#"><i class="fab fa-instagram" aria-hidden="true"></i></a></li>
                        <li><a href="#"><i class="fab fa-linkedin" aria-hidden="true"></i></a></li>
                    </ul>
                </div>
            </div>    
        </div>
    </div>
    <!-- footer ends -->


    <!-- *Scripts* -->
    <script src="js/jquery-3.5.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/particles.js"></script>
    <script src="js/particlerun.js"></script>
    <script src="js/plugin.js"></script>
    <script src="js/main.js"></script>
</body>
</html>