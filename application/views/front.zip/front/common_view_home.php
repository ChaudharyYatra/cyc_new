<?php 
$this->load->view('front/front_header');
$this->load->view('front/'.$middle_content);
$this->load->view('front/front_footer_home');
?>