<style>
  .hide {
    display: none;
    }
  .search_btn{
    margin-top: 20px;
    }
</style>
<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1><?php echo $module_title; ?></h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <a href="<?php echo $module_url_path; ?>/index"><button class="btn btn-primary">Back</button></a>
              
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- jquery validation -->
            <?php $this->load->view('admin/layout/admin_alert'); ?>
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title"><?php echo $page_title; ?></h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form method="post" enctype="multipart/form-data" id="add_package">
                <div class="card-body">
                 <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Which is payment type ?</label> <br>
                            <input type="radio" id="first_payment" name="payment_type" value="1" onclick="first_payment_main();"/>
                                <label for="Yes" id="first_payment">First Payment</label> &nbsp;&nbsp;
                            <input type="radio" id="partially_payment" name="payment_type" value="0" onclick="partially_payment_sub();"/>
                                <label for="No" id="partially_payment">Partial Payment</label> <br>
                        </div>
                    </div>
                    <div class="col-md-6">
                    </div>

                    <!--  firstly payment fields -->
                        <div class="col-md-6" id="sra_no_div" style="display:none;">
                            <div class="form-group">
                            <label>SRA No</label>
                            <input type="text" class="form-control" name="sra_no" id="sra_no" placeholder="Enter SRA No" required="required">
                            </div>
                        </div>

                        <div class="col-md-6" id="tour_number_div" style="display:none;">
                            <div class="form-group">
                            <label>Tour Number</label>
                            <input type="text" class="form-control" name="tour_number" id="tour_number" placeholder="Enter Tour Number" required="required">
                            </div>
                        </div>

                        <div class="col-md-6" id="to_date_div" style="display:none;">
                              <div class="form-group">
                                <label>Tour Date</label>
                                <input type="date" class="form-control" name="tour_date" id="tour_date" placeholder="Enter Rating" required="required">
                              </div>
                        </div>

                        <div class="col-md-6" id="customer_name_div" style="display:none;">
                            <div class="form-group">
                            <label>Customer Name</label>
                            <input type="text" class="form-control" name="customer_name" id="customer_name" placeholder="Enter customer name" required="required">
                            </div>
                        </div>

                        <div class="col-md-6" id="mobile_number_div" style="display:none;">
                            <div class="form-group">
                            <label>Customer Mobile No.</label>
                            <input type="text" class="form-control" maxlength="10" minlength="10" name="mobile_number" id="mobile_number" placeholder="Enter mobile number" required="required">
                            </div>
                        </div>

                        <div class="col-md-6" id="total_seat_div" style="display:none;">
                            <div class="form-group">
                            <label>Total Seat</label>
                            <input type="text" class="form-control" name="total_seat" id="total_seat" placeholder="Enter total seat" required="required">
                            </div>
                        </div>

                        <div class="col-md-6" id="total_srs_amt_div" style="display:none;">
                            <div class="form-group">
                            <label>Total SRA Amount</label>
                            <input type="text" class="form-control" name="total_sra_amt" id="total_sra_amt" placeholder="Enter total SRA amount" required="required">
                            </div>
                        </div>

                        <div class="col-md-6" id="image_name_div" style="display:none;">
                            <div class="form-group">
                            <label>SRA Upload Image / Pdf</label><br>
                            <input type="file" name="image_name" id="image_nam" required="required">
                            <br><span class="text-danger">Please select only JPG,PNG,JPEG,PDF format files.</span>
                            </div>
                        </div>

                        <!-- <div class="card-footer" id="first_submit_div" style="display:none;">
                            <button type="submit" class="btn btn-primary" name="submit" value="submit" id="first_submit">Submit</button>
                        </div> -->
                                <div class="col-md-3" id="otp1" style="display:none;">
                                </div>
                                <div class="col-md-6" id="otp" style="display:none;">
                                    <h5> SRA Confirmation OTP</h5>
                                    <table id="example2" class="table table-bordered table-hover table-striped">
                                        <tr>
                                            <th><input type="text" class="form-control" name="sra_otp" id="sra_otp" placeholder="Enter OTP" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');"> 
                                            <p id="booking_least_count"></p>
                                            </th>
                                            
                                            <th><button type="submit" class="btn btn-success" name="submit" id="first_submit" value="submit" disabled>Verify OTP</button></th>
                                            <!-- data-bs-toggle="modal" data-bs-target="#exampleModal_send" -->
                                            <!-- <a data-bs-toggle="modal" data-bs-target="#exampleModal" class="enq_id" data-bs-whatever="Form" data-enq-id="<?php //echo $enq_id;?>"><button type="button" class="btn btn-primary btn-sm btn_follow take_followup_btn" class="dropdown-item">Take Followup</button> </a> -->
                                        </tr>
                                    </table>

                                    <div class="row justify-content-center">
                                            <div class="col-md-1">
                                            </div>
                                            <div class="col-md-3">
                                                <center><button type="button" class="btn btn-primary mb-3" name="sra_submit_otp" id="sra_submit_otp">Send OTP</button></center>
                                            </div>
                                            <div class="col-md-4 send_btn">
                                                <center><button type="button" class="btn btn-primary mb-3" name="sra_re_send_otp" id="sra_re_send_otp" disabled>Resend OTP</button></center>
                                            </div>
                                            <div class="col-md-1">
                                            </div>
                                        </div>
                                </div>
                                <div class="col-md-3" id="otp2" style="display:none;">
                                </div>
                    <!--  firstly payment fields -->

                    <!--  Partially payment fields -->
                    <div class="col-md-2 mb-3" id="partially_submit_div" style="display:none;">
                            <button type="button" class="btn btn-primary search_btn" name="p_submit" value="submit" id="partially_submit">Search</button>
                    </div>

                    <!--  Partially payment fields -->

                      <!-- <div class="col-md-6">
                        <div class="form-group">
                          <label>Tour Type</label> <br>
                            <input type="radio" id="main_tour" name="tour_type" value="1" onclick="main();"/>
                                <label for="Yes" id="main_tour">Main Tour</label> &nbsp;&nbsp;
                            <input type="radio" id="sub_tour" name="tour_type" value="0" onclick="sub();"/>
                                <label for="No" id="sub_tour">Sub Tour</label> <br>
                        </div>
                      </div> -->
              </div>
                <!-- /.card-body -->
                
              </form>

              <div id="partial_table" style="display:none;">
                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                      <tr>
                    <th>SN</th>
                    <th>Tour No</th>
                    <th>Tour Date</th>
                    <th>Customer Name</th>
                    <th>Total Seat</th>
                    <th>Total SRA Amount</th>
                    <th>SRA Upload Image / Pdf</th>
                  </tr>
                  </thead>
                  <tbody id="tid">
                  
                  </tbody>
                </table>
              </div>
            </div>
            <!-- /.card -->
            </div>
          <!--/.col (left) -->
          <!-- right column -->
          <div class="col-md-6">

          </div>
          <!--/.col (right) -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  

  <script>
    function partially_payment_sub(){
    document.getElementById('sra_no_div').style.display = 'block';
    document.getElementById('mobile_number_div').style.display = 'block';
    document.getElementById('partially_submit_div').style.display = 'block';
    document.getElementById('partial_table').style.display = 'block';
    
    document.getElementById('otp').style.display = 'none';
    document.getElementById('otp1').style.display = 'none';
    document.getElementById('otp2').style.display = 'none';
    document.getElementById('tour_number_div').style.display = 'none';
    document.getElementById('to_date_div').style.display = 'none';
    document.getElementById('customer_name_div').style.display = 'none';
    document.getElementById('total_seat_div').style.display = 'none';
    document.getElementById('total_srs_amt_div').style.display = 'none';
    document.getElementById('image_name_div').style.display = 'none';
    document.getElementById('first_submit_div').style.display = 'none';
    }

    function first_payment_main(){
    document.getElementById('partially_submit_div').style.display = 'none';
    document.getElementById('partial_table').style.display = 'none';

    document.getElementById('otp').style.display = 'block';
    document.getElementById('otp1').style.display = 'block';
    document.getElementById('otp2').style.display = 'block';
    document.getElementById('sra_no_div').style.display = 'block';
    document.getElementById('tour_number_div').style.display = 'block';
    document.getElementById('to_date_div').style.display = 'block';
    document.getElementById('customer_name_div').style.display = 'block';
    document.getElementById('mobile_number_div').style.display = 'block';
    document.getElementById('total_seat_div').style.display = 'block';
    document.getElementById('total_srs_amt_div').style.display = 'block';
    document.getElementById('image_name_div').style.display = 'block';
    document.getElementById('first_submit_div').style.display = 'block';
    // document.getElementById('main_tour_id').value = "";
    }
</script>


